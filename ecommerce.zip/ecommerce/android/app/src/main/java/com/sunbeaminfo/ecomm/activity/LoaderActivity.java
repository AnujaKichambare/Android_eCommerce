package com.sunbeaminfo.ecomm.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.sunbeaminfo.ecomm.R;

public class LoaderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
