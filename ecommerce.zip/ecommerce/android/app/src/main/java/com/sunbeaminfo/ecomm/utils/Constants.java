package com.sunbeaminfo.ecomm.utils;

public class Constants {
    public static final String BASE_URL = "http://15.206.75.235:4000";

    public static final String PATH_PRODUCT = "/product";
    public static final String PATH_USER = "/user";
    public static final String PATH_CATEGORY = "/category";
}
